package com.example.ansible.ansible_artifact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnsibleArtifactApplicationTests {

	@Test
	void contextLoads() {
	}

}
