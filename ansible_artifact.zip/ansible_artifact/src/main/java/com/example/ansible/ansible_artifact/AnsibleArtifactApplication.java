package com.example.ansible.ansible_artifact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnsibleArtifactApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnsibleArtifactApplication.class, args);
	}

}
